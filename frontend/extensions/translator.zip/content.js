console.log("Translator running");

async function processMessages(){

let messages=document.querySelectorAll("[data-pre-plain-text] span");

messages.forEach(msg=>{

if(msg.dataset.translated) return;

msg.dataset.translated="true";

let text=msg.innerText;

chrome.runtime.sendMessage({

type:"translate",
text:text,
lang:"en"

},function(response){

let translated=response.translated;

let div=document.createElement("div");

div.style.fontSize="12px";
div.style.color="#00a884";

div.innerText=translated;

msg.parentElement.appendChild(div);

});

});

}

setInterval(processMessages,2000);