document.getElementById("save").addEventListener("click",function(){

let lang=document.getElementById("lang").value

chrome.storage.sync.set({
lang:lang
})

alert("Language saved")

})