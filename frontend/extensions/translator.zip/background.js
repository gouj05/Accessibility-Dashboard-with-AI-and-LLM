chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {

if(request.type==="translate"){

fetch("http://127.0.0.1:8000/translate",{

method:"POST",

headers:{
"Content-Type":"application/json"
},

body:JSON.stringify({
text:request.text,
target_lang:request.lang
})

})
.then(res=>res.json())
.then(data=>{

sendResponse(data)

})

return true
}

})