const startBtn = document.getElementById('start-btn');
const output = document.getElementById('output');

const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
const recognition = new SpeechRecognition();
recognition.continuous = true;
recognition.interimResults = true;

recognition.onresult = (event) => {
  let finalTranscript = '';
  for (let i = 0; i < event.results.length; i++) {
    finalTranscript += event.results[i][0].transcript;
  }
  
  output.value = finalTranscript;

chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
  if (tabs[0] && tabs[0].url.includes("whatsapp.com")) {
    chrome.tabs.sendMessage(tabs[0].id, {
      type: "INSERT_TEXT",
      text: finalTranscript
    }, (response) => {
      if (chrome.runtime.lastError) {
        console.error("Error sending message:", chrome.runtime.lastError);
      }
    });
  }
});
};

startBtn.addEventListener('click', () => {
  recognition.start();
  startBtn.innerText = "Listening...";
  startBtn.style.background = "#ea4335"; // Turn red when recording
});