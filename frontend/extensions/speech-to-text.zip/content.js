let lastFocusedElement = null;

// Track the input box on WhatsApp
document.addEventListener('mousedown', (e) => {
  const target = e.target.closest('[contenteditable="true"], input, textarea');
  if (target) {
    lastFocusedElement = target;
    console.log("Target Locked");
  }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === "INSERT_TEXT") {
    // 1. Find the WhatsApp typing area (it's a div with a specific class usually)
    const target = document.querySelector('div[contenteditable="true"][role="textbox"]') || 
                   document.querySelector('div[contenteditable="true"]') || 
                   document.activeElement;

    if (target) {
      target.focus();

      // 2. Select all existing text to replace it (prevents doubling)
      const selection = window.getSelection();
      const range = document.createRange();
      range.selectNodeContents(target);
      selection.removeAllRanges();
      selection.addRange(range);

      // 3. TRY METHOD A: execCommand (Most reliable for rich text)
      const added = document.execCommand('insertText', false, request.text);

      // 4. TRY METHOD B: If Method A failed, force the text in manually
      if (!added || target.innerText !== request.text) {
        target.innerText = request.text;
      }

      // 5. THE CRITICAL STEP: Trigger events so the 'Send' button appears
      // We trigger 'input' and 'change' so React knows the state updated
      const inputEvent = new Event('input', { bubbles: true });
      target.dispatchEvent(inputEvent);
      
      const changeEvent = new Event('change', { bubbles: true });
      target.dispatchEvent(changeEvent);

      sendResponse({status: "Success"});
    } else {
      console.error("WhatsApp text box not found!");
    }
  }
  return true;
});