document.getElementById("speak").addEventListener("click", () => {

  const rate = document.getElementById("rate").value;

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {

    chrome.tabs.sendMessage(tabs[0].id, {
      action: "speak",
      rate: rate
    });

  });

});


document.getElementById("stop").addEventListener("click", () => {

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {

    chrome.tabs.sendMessage(tabs[0].id, {
      action: "stop"
    });

  });

});