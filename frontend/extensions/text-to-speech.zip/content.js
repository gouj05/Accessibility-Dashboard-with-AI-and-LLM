let speech = window.speechSynthesis;

chrome.runtime.onMessage.addListener((request) => {

  if (request.action === "speak") {

    const selectedText = window.getSelection().toString();

    if (!selectedText) {
      alert("Please select text first!");
      return;
    }

    const utterance = new SpeechSynthesisUtterance(selectedText);

    utterance.rate = request.rate;

    speech.speak(utterance);
  }

  if (request.action === "stop") {
    speech.cancel();
  }

});